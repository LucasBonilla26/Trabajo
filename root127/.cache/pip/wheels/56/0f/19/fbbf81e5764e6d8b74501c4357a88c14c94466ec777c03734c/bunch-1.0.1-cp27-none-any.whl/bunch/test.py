#!/usr/bin/env python
# -*- coding: utf-8 -*-

def test():
    import bunch
    import doctest
    doctest.testmod(bunch)

if __name__ == '__main__':
    test()
